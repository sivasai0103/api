from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from .models import *
from .forms import *
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from .decorators import *
from django.contrib.auth.models import Group
from .filters import Filter
# Create your views here.

@login_required(login_url='login')
@admin_only
def home(request):
    breakfast=Category.objects.filter(name='shareholder')[0].item_set.all()
    customers=Customer.objects.all()
    context={'shareholder':shareholder}
    return render(request,'main.html',context)

@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def fooditem(request):
    shareholder=Category.objects.filter(name='shareholder')[0].item_set.all()
    bcnt=shareholder.count()
    context={'shareholder':shareholder,
              'bcnt':bcnt
            }
    return render(request,'shareholder.html',context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def createholders(request):
    form = shareholderForm()
    if request.method == 'POST':
        form = shareholderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    context={'form':form}
    return render(request,'createholder.html',context)

def addFooditem(request):
    user=request.user
    cust=user.customer
    if request.method=="POST":
        form =addshareholder(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')
    form=addshareholder()
    context={'form':form}
    return render(request,'addshareholder.html',context)

@unauthorized_user
def loginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            messages.info(request,'username or password is invalid')
    return render(request,'login.html')

@login_required(login_url='login')
def logoutUser(request):
    logout(request)
    return redirect('login')

    
def userPage(request):
    user=request.user
    cust=user.customer
    shareholders=Shareholder.objects.filter()
    myfilter = Filter(request.GET,queryset=shareholders)
    shareholders=myfilter.qs
    total=User.objects.all()
    holderslist=total.filter(customer=cust)
    cnt=holderslist.count()
    querysetFood=[]
    for food in holderslist:
        querysetFood.append(food.fooditem.all())
    final=[]
    for items in querysetFood:
        for shares_list in items:
            final.append(shares_list)
    total_list=0
    for shares in final:
        total_list+=shares.calorie
    Res = 2000-total_list
    context={'Res':Res,'total_list':total_list,'cnt':cnt,'final':final,'shareholders':shareholders,'myfilter':myfilter}
    return render(request,'user.html',context)