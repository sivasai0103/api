# Django---DRF-basic-Rest-API-

Medium Blog.  https://medium.com/@sjlouji10/django-rest-framework-creating-a-simple-api-in-15mins-with-drf-5e051ee531dd?source=friends_link&sk=234faf0703c6c6e0f99519fea63a7fac
