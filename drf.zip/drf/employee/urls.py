from django.urls import path
from .api import EmployeeCreateApi, EmployeeApi, EmployeeUpdateApi,EmployeeDeleteApi
urlpatterns = [
    path('apicreate/',EmployeeCreateApi.as_view()),
    path('apiview/',EmployeeApi.as_view()),
    path('api/<int:pk>',EmployeeUpdateApi.as_view()),
    path('api/<int:pk>/del',EmployeeDeleteApi.as_view()),
]