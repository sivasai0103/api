from django.apps import AppConfig


class ShareappConfig(AppConfig):
    name = 'shareapp'
