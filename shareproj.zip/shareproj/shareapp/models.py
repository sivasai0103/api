from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Customer(models.Model):
    name=models.CharField(max_length=200,null=True)
    email=models.EmailField(max_length=200,null=True)
    mobile_number=models.IntegerField(max_length=200,null=True)
    country=models.CharField(max_length=200,null=True)
    
    def __str__(self):
        return str(self.name)

class Category(models.Model):
    options=(('shareholder','shareholder'))
    name=models.CharField(max_length=50,choices=options)
    def __str__(self):
        return self.name

class Shareholder(models.Model):
    name = models.CharField(max_length=200)
    duration_year = models.DateField()
    installment_type = models.DecimalField(max_digits=5,decimal_places=2,default=0)
    payment_mode = models.FloatField(max_length=200,null=True)
    Total_amount = models.FloatField(max_length=2000)
    start_date=models.DateField()
    office_staff = models.IntegerField(default=1,null=True,blank=True)
    
    def __str__(self):
        return str(self.name)

class User(models.Model):
    customer = models.ManyToManyField(Customer,blank=True)
    Shareholder=models.ManyToManyField(Shareholder)